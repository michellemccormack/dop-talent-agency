// functions/heygen-video-processor.js
// Poll pending HeyGen tasks stored in persona blobs and write back video_url.
// Runs on demand and via Netlify schedule (see netlify.toml snippet below).

const { getStore } = require('@netlify/blobs');

const STORE_NAME = 'dop-uploads';          // matches your dop-file.js REST path
const PERSONA_PREFIX = 'personas/';        // personas/<dopId>.json
const POLL_LIMIT_MS = 180000;              // max time per invocation
const SLEEP_MS = 3500;

function cors(extra={}) {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'content-type',
    'Content-Type': 'application/json',
    ...extra
  };
}

const sleep = (ms)=> new Promise(r=>setTimeout(r,ms));

function ok(body){ return { statusCode:200, headers:cors(), body:JSON.stringify(body) }; }
function err(code,msg,extra={}){ return { statusCode:code, headers:cors(), body:JSON.stringify({ error:msg, ...extra }) }; }

async function checkHeygenTask(task_id){
  const r = await fetch(`/.netlify/functions/heygen-proxy?action=check_video&task_id=${encodeURIComponent(task_id)}`);
  const j = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(`check_video failed ${r.status}`);
  // normalize
  const status = j.status || j?.data?.status;
  const video_url = j.video_url || j?.data?.video_url;
  const thumbnail_url = j.thumbnail_url || j?.data?.thumbnail_url || null;
  const duration = j.duration || j?.data?.duration || null;
  return { status, video_url, thumbnail_url, duration };
}

function hasAllVideos(persona){
  const want = (persona.prompts || [{key:'fun'},{key:'from'},{key:'relax'}]).map(p=>p.key);
  const got = new Set((persona.videos||[]).map(v => v.key || v.prompt));
  return want.every(k => got.has(k));
}

async function processPersona(store, key){
  const raw = await store.get(key, { type:'text' });
  if (!raw) return { key, status:'skip', reason:'missing blob' };
  let persona;
  try { persona = JSON.parse(raw); } catch { return { key, status:'skip', reason:'bad json' }; }

  persona.videos ||= [];
  persona.prompts ||= [{key:'fun',text:'What do you like to do for fun?'},{key:'from',text:'Where are you from?'},{key:'relax',text:'What’s your favorite way to relax?'}];
  persona.pending ||= {}; // { fun:{task_id}, ... }

  // nothing to do?
  if (!Object.keys(persona.pending).length && hasAllVideos(persona)) {
    if (persona.status !== 'ready') {
      persona.status = 'ready';
      await store.set(key, JSON.stringify(persona), { contentType:'application/json' });
    }
    return { key, status:'ready' };
  }

  const start = Date.now();
  let changed = false;

  while (Date.now() - start < POLL_LIMIT_MS) {
    let remaining = 0;

    for (const [k, info] of Object.entries(persona.pending)) {
      if (!info?.task_id) continue;
      // already captured?
      if ((persona.videos||[]).some(v => (v.key||v.prompt) === k)) continue;

      try {
        const res = await checkHeygenTask(info.task_id);
        if (res.status === 'completed' && res.video_url) {
          persona.videos.push({ key:k, url:res.video_url, thumbnail_url:res.thumbnail_url, duration:res.duration });
          delete persona.pending[k];
          changed = true;
        } else if (res.status === 'failed') {
          persona.failures ||= {};
          persona.failures[k] = 'render failed';
          delete persona.pending[k];
          changed = true;
        } else {
          remaining++;
        }
      } catch (e) {
        // transient error; keep it pending
        remaining++;
      }
    }

    if (!remaining) break;
    await sleep(SLEEP_MS);
  }

  persona.status = hasAllVideos(persona) ? 'ready' : 'processing';
  if (changed) {
    await store.set(key, JSON.stringify(persona), { contentType:'application/json' });
  }
  return { key, status: persona.status };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:cors(), body:'' };
  try {
    const store = getStore({
      name: STORE_NAME,
      siteID: process.env.NETLIFY_SITE_ID,
      token: process.env.NETLIFY_BLOBS_TOKEN,
      consistency: 'strong'
    });

    const list = await store.list({ prefix: PERSONA_PREFIX });
    const items = (list?.blobs || list || []).filter(x => String(x.key || x).endsWith('.json'));

    const results = [];
    for (const item of items) {
      const key = item.key || item;
      const res = await processPersona(store, key);
      results.push(res);
    }
    return ok({ processed: results.length, results });
  } catch (e) {
    return err(500, 'processor_failed', { message: String(e?.message||e) });
  }
};
